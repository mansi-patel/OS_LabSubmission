du -a | sort -n -r | head -n 2
