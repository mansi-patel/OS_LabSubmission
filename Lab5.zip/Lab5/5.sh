echo Enter the first filename
read f1
echo Enter the second filename
read f2
if [ -e $f1 ]
then
if [ -e $f2 ]
then
cat $f1 >> $f2
else
cat $f1 > $f2
fi
fi
