if [ $# -gt 0 ]
then
x=`echo $1 | wc -c`
x=`expr $x - 1`
word=""
while [ $x -gt 0 ]
do
c=`echo $1 | cut -c $x`
x=`expr $x - 1`
word=$word$c
done
fi
echo The reverse string is $word
