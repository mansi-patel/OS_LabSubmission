echo "Enter the word"
read word
echo "Enter the number of times you want to print that word"
read num
for (( i = 0 ; i < $num ; i++ ))
do
echo "$word"
done
