echo "Enter a string"
read string
