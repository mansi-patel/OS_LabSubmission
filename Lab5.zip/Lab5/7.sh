echo "Enter the first alphabet from which you want to search files"
read alphabet
ls $alphabet* 
