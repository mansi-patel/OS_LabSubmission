echo "Enter the number upto which you want the summation"
read num
a=`expr $num + 1` 
b=`expr $num \\* $a` 
total=`expr $b / 2` 
echo Sum upto $num is $total
a1=`expr 50 + 1` 
b1=`expr 50 \\* $a1` 
total1=`expr $b1 / 2`
echo Summation of first 50 numbers is $total1
